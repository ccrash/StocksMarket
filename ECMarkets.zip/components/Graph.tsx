import React, { useState } from 'react';
import { View, Text, StyleSheet, Button } from 'react-native';
import { VictoryChart, VictoryLine, VictoryZoomContainer, VictoryAxis, VictoryLegend } from 'victory-native';
import type { StockPoint } from '../api/FetchStockData';

interface Props {
  data: StockPoint[];
  isDark: boolean;
}

export default function GraphSection({ data, isDark }: Props) {
  const [visibleSeries, setVisibleSeries] = useState({
    open: true,
    close: true,
    low: true,
    high: true,
  });

  const [zoomDomain, setZoomDomain] = useState<any>(undefined);

  const toggleSeries = (key: keyof typeof visibleSeries) => {
    setVisibleSeries(prev => ({ ...prev, [key]: !prev[key] }));
  };

  const resetZoom = () => {
    setZoomDomain(undefined);
  };

  const handleZoomDomainChange = (domain: any) => {
    setZoomDomain(domain);
  };

  const seriesColors = {
    open: "blue",
    close: "green",
    low: "orange",
    high: "red",
  };

  return (
    <View>
      <VictoryChart
        containerComponent={
          <VictoryZoomContainer
            zoomDimension="x"
            zoomDomain={zoomDomain}
            onZoomDomainChange={handleZoomDomainChange}
          />
        }
      >
        <VictoryAxis fixLabelOverlap tickFormat={(t) => `${new Date(t).toLocaleDateString()}`} />
        <VictoryAxis dependentAxis />

        {Object.entries(visibleSeries).map(([key, visible]) => (
          visible && (
            <VictoryLine
              key={key}
              data={data.map(d => ({ x: new Date(d.date + 'T00:00:00'), y: d[key as keyof StockPoint] }))}
              style={{ data: { stroke: seriesColors[key as keyof typeof visibleSeries] } }}
            />
          )
        ))}
      </VictoryChart>

      <View style={styles.controls}>
        {Object.keys(visibleSeries).map(key => (
          <Button key={key} title={`${visibleSeries[key as keyof typeof visibleSeries] ? 'Hide' : 'Show'} ${key}`} onPress={() => toggleSeries(key as keyof typeof visibleSeries)} />
        ))}
        <Button title="Reset Zoom" onPress={resetZoom} />
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  controls: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-around',
    marginTop: 10,
  },
});
